<?php
$conn = new mysqli("localhost","root","","secure_auth");
?>