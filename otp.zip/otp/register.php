<?php
include "config.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    if (empty($username) || empty($email) || empty($password)) {
    echo "All fields are required.";
    } else {
    $stmt = $conn->prepare("INSERT INTO users (username, password_hash, email)
   VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $password, $email);
    echo $stmt->execute() ? "Success":"Failed";
    $stmt->close();
    }
    $conn->close();
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
</head>
<body>
    <h2>Register</h2>
    <form method="post">
    Username: <input type="text" name="username"><br>
    Email: <input type="text" name="email"><br>
    Password: <input type="password" name="password"><br>
    <input type="submit" value="Register">
</form>
    
</body>
</html>