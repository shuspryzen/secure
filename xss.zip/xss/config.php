<?php
$conn = new mysqli("localhost","root","","xss_test");
?>