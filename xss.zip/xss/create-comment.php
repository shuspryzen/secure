<?php
include "config.php";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = trim($_POST["username"]);
    $comment = trim($_POST["comment"]);
    if(!$username || !$comment){ echo "Enter the details";}
    else{
        $smtm = $conn->prepare("INSERT into comments(username,comment) values(?,?)");
        $smtm->bind_param("ss",$username,$comment);
        echo $smtm->execute() ? "Success" : "Failed";
        $smtm->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Create Comment</title>
</head>
<body>
    <h2>Comment Creation</h2>
    <form method="POST">
        Username: <input type="text" name="username"><br>
        Comment: <textarea name="comment" ></textarea><br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>