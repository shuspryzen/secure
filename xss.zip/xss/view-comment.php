<?php
include "config.php";
$query = "SELECT username,comment from comments";
$smtm = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>View Comments</title>
</head>
<body>
    <h2>View Comments</h2>
    <?php
    if($smtm->num_rows > 0){
        while($row = $smtm->fetch_assoc()){
            echo "<p><strong>".$row["username"].": </strong>".$row["comment"]."</p>";
        }
    }
    else{ echo "No comments";}
    $conn->close();
    ?>
</body>
</html>