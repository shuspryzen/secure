<?php
$conn = new mysqli("localhost","root","","sql_injection_test");
?>