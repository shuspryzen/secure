<?php
include "config.php";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    if(!$username){ echo "Enter username";}
    elseif(!$password){echo "Enter Password";}
    else{
        $query = "SELECT username,password from users where username = '$username' and password = '$password'";
        $smtm = $conn->query($query);

        if($smtm->num_rows > 0){
            echo "Login Success";
        }
        else{
            echo "Login Failed";
        }
        $smtm->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
</head>
<body>
    <form method="POST">
    Username: <input type="text" name="username"><br>
    Password: <input type="password" name="password"><br>
    <input type="submit" value="Login">

    </form>
</body>
</html>