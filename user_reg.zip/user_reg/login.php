<?php
include "config.php";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    if(!$username){ echo "Please enter username";}
    elseif(!$password){ echo "Please enter password";}
    else{
        $stmt = $conn -> prepare("SELECT id,username,password from users where username = ?");
        $stmt->bind_param("s",$username);
        $stmt->execute();
        $stmt->store_result();

        if($stmt->num_rows == 1){
            $stmt->bind_result($id,$username,$dbpassword);
            $stmt->fetch();
            if($password == $dbpassword){
                $_SESSION["username"] = $username;
                $_SESSION["id"] = $id;
                header("location: welcome.php");
                exit;
            }else{
                echo "The password is worng";
            }
        }else{
            echo "No Username Found";
        }
        $stmt->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
</head>
<body>
<h2>Login</h2>
 <form method="post">
 Username: <input type="text" name="username"><br>
 Password: <input type="password" name="password"><br>
 <input type="submit" value="Login">
</form>
</body>
</html>