<?php
include "config.php";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    if(!$username){ echo "Please enter username";}
    elseif(!$password){ echo "Please enter password";}
    else{
        $stmt = $conn -> prepare("SELECT id from users where username = ?");
        $stmt->bind_param("s",$username);
        $stmt->execute();
        $stmt->store_result();

        if($stmt->num_rows){
            echo "Username already taken";
        }
        else{
            $stmt->close();
            $stmt = $conn->prepare("INSERT into users(username,password) values(?,?)");
            $stmt->bind_param("ss",$username,$password);
            echo $stmt->execute() ? "Registration Success":"Retry";
        }
        $stmt->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
</head>
<body>
<h2>Register</h2>
 <form method="post">
 Username: <input type="text" name="username"><br>
 Password: <input type="password" name="password"><br>
 <input type="submit" value="Register">
</form>
</body>
</html>