<!DOCTYPE html>
<html>
<body>
 <h2>Welcome</h2>
 <p>Welcome, You have successfully logged in.</p>
 <a href="logout.php">Logout</a>
</body>
</html>