<?php
include 'config.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $allowedTypes = ["image/jpeg", "image/png", "application/pdf"];
    if (isset($_FILES["fileToUpload"])) {
        $fileName = basename($_FILES["fileToUpload"]["name"]);
        $fileType = $_FILES["fileToUpload"]["type"];
        $fileTempPath = $_FILES["fileToUpload"]["tmp_name"];
        echo $fileTempPath;
        if (!in_array($fileType, $allowedTypes)) {
            die("Error: Unsupported file type.");
        }
        $storagePath = __DIR__ . '/secure_uploads/';
        if (!is_dir($storagePath)) {
            mkdir($storagePath, 0700, true); 
        }
        $targetFilePath = $storagePath . $fileName;
        if (move_uploaded_file($fileTempPath, $targetFilePath)) {
            $stmt = $conn->prepare("INSERT INTO files (filename, file_type) VALUES (?, ?)");
            $stmt->bind_param("ss", $fileName, $fileType);
            echo ($stmt->execute()) ? "File uploaded and saved securely.":"Failed to save file information.";
            $stmt->close();
        } else {
            echo "Error: File upload failed.";
        }
    } else {
        echo "No file uploaded or file too large.";
    }
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Secure File Upload</title>
</head>
<body>
    <h2>Upload File</h2>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="fileToUpload" required>
        <input type="submit" value="Upload File">
    </form>
</body>
</html>